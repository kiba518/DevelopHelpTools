﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Host
{
    /// <summary>
    /// MainWindow.xaml 的交互逻辑
    /// </summary>
    public partial class MainWindow : Window
    {
        public MyTcpListener myTcpListener;
        public MainWindow()
        {
            InitializeComponent();
        }
        #region 开启TCP监听
        private void BtnTcp_Click(object sender, RoutedEventArgs e)
        {
            myTcpListener = new MyTcpListener(txtTcpHost.Text, int.Parse(txtTcpPort.Text), Callback);
            myTcpListener.StartListen();
            MessageBox.Show("主机已开启");
        }
        public void Callback(string readData)
        {

        }
        #endregion
    }
}
