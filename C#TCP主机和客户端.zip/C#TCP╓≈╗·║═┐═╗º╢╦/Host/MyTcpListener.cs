﻿ 
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading.Tasks;
 
namespace Host
{
    public class MyTcpListener
    {
        [ThreadStatic]
        public static NetworkStream stream;
        TcpListener TcpServer { get; set; }
        TcpClient Client { get; set; }
        public int Port { get; set; }
        public string IP { get; set; }
        public int MaxRead { get; set; }
        public bool Closed { get; set; }
        public Action<string> Callback { get; set; } 

        public MyTcpListener(string ip, int port, Action<string> callback, int maxRead = 1024)
        {
            Callback = callback;
            Closed = false;
            IP = ip;
            Port = port;
            MaxRead = maxRead;//256Byte=128个汉字 最大接收字符串数量
            Client = new TcpClient();
            IPAddress localAddr = IPAddress.Parse(IP);
            TcpServer = new TcpListener(localAddr, Port);
            TcpServer.Start();
        }

        public void StartListen()
        {
            Closed = false;
            Task tank = new Task(Listen);
            tank.Start();
        }

        public void Close()
        {
            try
            {
                Closed = true;
                Client.Close();
                TcpServer.Stop();
            }
            catch (Exception ex)
            {
               
            }
        }
        public void Listen()
        {
            try
            {  
                Byte[] bytes = new Byte[MaxRead];//256Byte=128个汉字 最大接收字符串数量
                String readData = null;
                while (true)
                {
                    if (Closed)
                    {
                        break;
                    }
                    
                    Client = TcpServer.AcceptTcpClient();
                   
                    readData = null;
                    stream = Client.GetStream();
                    int i;
                    if (stream.CanRead)
                    {
                        StartListen();
                        i = stream.Read(bytes, 0, bytes.Length);
                        readData = System.Text.Encoding.Default.GetString(bytes, 0, i);//接收到的数据
                          
                        Callback(readData);
                        string returnData = @"</end>"; //</end>标记消息传递结束
                        returnData = "<Message>1</Message>" + returnData;  

                        byte[] msg = System.Text.Encoding.Default.GetBytes(returnData);
                        stream.Write(msg, 0, msg.Length); 
                        stream.Close();

                    }
                    else
                    {
                        
                    }

                }

            }
            catch (SocketException ex)
            {
                Callback(ex.Message); 
            }
            finally
            {

            }



        }
    }
}
