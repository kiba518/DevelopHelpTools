﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Net;
using System.Net.Sockets;

namespace Client
{
    /// <summary>
    /// MainWindow.xaml 的交互逻辑
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
         
        } 
        private void BtnTcp_Click(object sender, RoutedEventArgs e)
        {
            string message = "api status\n\n";
            Send(message);
        }
        private void Send(string message)
        {
            TcpClient TcpClient = new TcpClient(txtTcpHost.Text, int.Parse(txtTcpPort.Text));

            Byte[] data = System.Text.Encoding.Default.GetBytes(message);
            NetworkStream stream = TcpClient.GetStream();
            stream.Write(data, 0, data.Length);
            Byte[] bytes = new Byte[1024];

            if (stream.CanRead)
            {
                String datastr = "";
                while (true)
                {
                    try
                    {
                        int i = stream.Read(bytes, 0, bytes.Length);
                        if (bytes != null)
                        {
                            datastr += System.Text.Encoding.Default.GetString(bytes, 0, i);

                            if (datastr.Contains("</end>"))
                            {
                                break;
                            }
                            if (i == 0)
                            {
                                break;
                            }
                        }
                        else
                        {
                            break;
                        }
                    }
                    catch (Exception ex)
                    {

                    }
                }
                MessageBox.Show(datastr);
                stream.Close();
                TcpClient.Close();
            }
        }
    }
}
